DonutLike v1.1 - Fabric 1.21.4 (Java 21 + Fabric Loader + Fabric API 0.119.2+1.21.4)

BUILD LOCAL: cai JDK 21 + Gradle 8.12, mo terminal trong thu muc nay: gradle build
             -> build/libs/donutlike-1.1.0.jar -> bo vao mods (cung Fabric API)
BUILD GITHUB: push len GitHub -> tab Actions -> "Build mod" -> tai artifact "donutlike-mod".
              Muon tao Release: git tag v1.1.0 && git push origin v1.1.0

MOI TRONG v1.1
- Can cu rai rac: moi o 176x176 block co ~60% co 1 can cu (go / gach da 2 tang / ham obsidian),
  ~50% da bi raid (tuong thung, ruong bi lay do, mang nhen, ho bom, vun). Xay khi ban den gan.
  /randombase [intact|raided] (op) de sinh thu ngay canh ban.
- Bang ben phai (sidebar) kieu DonutSMP cu: tien, shards, kills, deaths, playtime, online. /sidebar de bat/tat.
- /baltop /killtop /shardtop /playtop (co hang cua ban o cuoi).

LENH: go /donuthelp trong game.
Duel: /duel bot <noob|normal|pro|cpvp> [tien cuoc]
      /duel custom <mau> <sat thuong> <toc do 0.1-0.6> <giap 0-4> <totem> <crystal true/false>
      /duel leave
Chinh bot o Duels.java (SPECS). Tien/gia o DonutLike.java va bang PRICES.
Chinh can cu o Bases.java (CELL, BASE_CHANCE, loot). Chinh sidebar o Hud.java (buildLines).

MOI TRONG v1.2 (DonutSMP cu)
- /ah (phan trang 45 mon/trang, sap xep, /ah sell <gia> toi da 5 mon, /ah search <ten>) - do do NGUOI CHOI dang, luu file, restart khong mat.
- /orders (alias /order): gia mua cao nhat o trang 1. /orders create <item> <sl> <gia/cai>: tien bi giu (escrow),
  nguoi khac click order de giao do -> tien chuyen cho ho, do bay vao tui nguoi dat. Nguoi dat offline => order huy, hoan tien.
- Combat: /ct /combat (15s), thoat game khi dang tag = chet + rot do, khong dung duoc /spawn /home /rtp /tpa. /pvp bat/tat; spawn 48 block luon khoa PvP.
- /suicide, /withdraw <tien> (to sec giay, chuot phai nap lai), /rankvoucher <player> <rank> (op) + /redeem (cam ve tren tay).
  Doi lenh rank o Notes.RANK_COMMAND (mac dinh lenh LuckPerms).
- Chong lag (AntiLag.java): gop quai "Creeper x100" (chem chet tru 1), don item roi khi >300, khoa no giuong (Nether/End) + Respawn Anchor (ngoai Nether).
- Amethyst: /amethyst <player> <sword|pickaxe|axe|shovel|helmet|chestplate|leggings|boots> (op). Tu huy sau 72h thuc, bao mau tim.
  Quet tui + ender chest moi 10s, ruong thi quet luc mo ruong.

MOI TRONG v1.3 - MENU ADMIN
- /dladmin (hoac /dlmenu, op): mo menu 54 o. Xanh = BAT, do = TAT cho tung tinh nang. Giay/so luong: chuot trai +, chuot phai -, shift x5.
  O Beacon = Master (tat toan bo mod, server chay nhu vanilla). TNT = reset mac dinh.
- Lenh: /dladmin list | toggle <key> | set <key> <so> | master | reset. Thiet lap luu trong config/donutlike.json.
- Tinh nang tat -> lenh tuong ung bi an (can vao lai server de client cap nhat goi y lenh).

MOI TRONG v1.4 (DonutSMP cu)
- /shop 3 tang: menu chinh (Gear/Nether/End/Food/Shard Shop) -> menu con 54 o -> chon so luong (-64 -10 -1 | item | +1 +10 +64, Confirm/Cancel). Sua hang o ShopHandler.java (add("gear", Items.X, gia)).
- MOI item/block deu co gia ban (Prices.java; bang PRICES o DonutLike.java ghi de). Re chuot vao item (client) hien "Sell: $x", ke ca do trong shulker. Tien dang 1 / 100K / 1M / 1B / 1T.
- Sidebar: Money, Shards, Kills, Deaths, Keyall (dem nguoc, het gio +1 shard cho tat ca), Playtime. Chu ky keyall chinh o /lananhadm menu (keyall_minutes).
- /sell : order cua NGUOI MUA AO (FakeMarket.java). Order cua ban (/orders create) duoc nguoi ban ao giao dan neu gia >= 90% gia tri.
- /shardshop : Amethyst (potion x2.5 shard, xo nuoc vo han, cup, cup 3x3, riu chat cay, riu sell) + spawner pig/cow/skeleton/blaze/creeper. SUA GIA SHARD O ShardShop.java (TOOL_PRICE, SPAWNER_PRICE) - minh khong co bang gia shard goc cua DonutSMP.
- /rtp : GUI (co=overworld, netherrack=nether, end stone=end), tim vi tri tung tick nen khong giat.
- /warp afk, khu spawn: /lananhadm buildspawn (xay tai cho dung + dat spawn), /lananhadm buildafk.
- /duel (khong tham so): mod tu chon bot theo giap ban mac. Fix duel bi day ve cho cu (chunk dau truong gio duoc nap + giu).
- /lananhadm : CHI admin. Chua co chu: op go /lananhadm setowner <ten>. Sau do lenh bi an voi nguoi khac (do/khong goi y). money|shards give|take|set <player> <1k|1m|1b|1t>, amethyst, menu, buildspawn, buildafk.
- Can cu rai rac day hon (o luoi 112, 85%).

MOI TRONG v1.5 - SPAWNER KIEU DONUTSMP (Spawners.java)
- Chuot phai spawner dang dat bang spawner cung loai = gop +1 (Shift = gop ca stack trong tay).
- Dat spawner moi: Shift + dat = dat ca stack thanh 1 spawner xN.
- Dao bang Silk Touch: lay 1 ra khoi stack; Shift + dao = lay ca stack (khong Silk Touch thi khong dao duoc).
- Spawner KHONG sinh quai, tu sinh DO vao kho moi 10s (bang LOOT trong Spawners.java). Chuot phai (khong Shift) = mo kho: click trai lay 1 stack, click phai ban het loai do, nut Ban tat ca.
- Spawner mua o /shardshop da co RequiredPlayerRange=0 (khong sinh quai that).
