package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Cho "ao" de choi mot minh:
 *  - /sell : GUI order cua NGUOI MUA AO (ten ao). Click = ban 1 stack, shift+click = ban het (toi da so con can).
 *  - Order cua BAN (/orders create ...) se duoc NGUOI BAN AO giao dan dan neu gia du hop ly.
 */
public class FakeMarket {

    static final String[] FAKE_NAMES = {"Alex_VN", "DonutKing", "xX_Miner_Xx", "Hana", "Bao123", "NoobMaster", "Zephyr", "TanSMP",
        "Minh_PvP", "CrystalGod", "Linh", "ShadowFox", "Kiet_TV", "PandaGamer", "Nguyen_MC", "Thanh2k8", "ObsidianLord", "EnderQueen",
        "Duc_Cpvp", "MeoMeo", "BigTotem", "RaidKing", "FarmBot99", "SkyBlockVN", "Quan_Mine", "TrangPro", "LavaCake", "IronGolem_", "Phuc_SMP", "DragonSlay"};

    static final Item[] POOL = {
        Items.DIAMOND, Items.EMERALD, Items.IRON_INGOT, Items.GOLD_INGOT, Items.NETHERITE_INGOT, Items.COAL, Items.REDSTONE,
        Items.LAPIS_LAZULI, Items.COPPER_INGOT, Items.OBSIDIAN, Items.ENDER_PEARL, Items.BLAZE_ROD, Items.GOLDEN_APPLE, Items.QUARTZ,
        Items.OAK_LOG, Items.COBBLESTONE, Items.DIRT, Items.SAND, Items.BONE, Items.GUNPOWDER, Items.STRING, Items.SLIME_BALL,
        Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.ARROW, Items.WHEAT, Items.CARROT, Items.POTATO, Items.SUGAR_CANE, Items.PUMPKIN,
        Items.MELON_SLICE, Items.COCOA_BEANS, Items.NETHER_WART, Items.GLOWSTONE_DUST, Items.END_STONE, Items.SHULKER_SHELL,
        Items.ANCIENT_DEBRIS, Items.DIAMOND_BLOCK, Items.IRON_BLOCK, Items.COOKED_BEEF, Items.BREAD, Items.TOTEM_OF_UNDYING
    };

    static class FO {
        String name; Item item; int remaining; double per;
    }

    static final List<FO> LIST = new ArrayList<>();
    static long bucket = -1;
    static final Random RND = new Random();

    static FO make(Random r) {
        FO o = new FO();
        o.name = FAKE_NAMES[r.nextInt(FAKE_NAMES.length)];
        o.item = POOL[r.nextInt(POOL.length)];
        int stack = Math.max(1, Math.min(64, o.item.getMaxCount()));
        o.remaining = stack * (1 + r.nextInt(24));
        double unit = Math.max(0.5, Prices.unit(o.item));
        o.per = Math.round(unit * (1.05 + r.nextDouble() * 0.55) * 100.0) / 100.0;
        return o;
    }

    static void ensure() {
        long b = System.currentTimeMillis() / 900_000L; // doi bo order moi 15 phut
        if (b == bucket && !LIST.isEmpty()) return;
        bucket = b;
        LIST.clear();
        Random r = new Random(b * 31 + 7);
        for (int i = 0; i < 45; i++) LIST.add(make(r));
        LIST.sort((x, y) -> Double.compare(y.per * y.remaining, x.per * x.remaining));
    }

    static void init() { }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("sell").requires(s -> Admin.on("orders")).executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
    }

    static void open(ServerPlayerEntity p) {
        ensure();
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54)), Text.literal("Sell - Orders")));
    }

    // ===== Nguoi ban ao giao hang cho order cua ban =====
    static void tick(MinecraftServer s) {
        if (DonutLike.tick % 100 != 0 || !Admin.on("orders")) return;
        Iterator<Market.Order> it = Market.ORDERS.iterator();
        while (it.hasNext()) {
            Market.Order o = it.next();
            if (System.currentTimeMillis() - o.created < 8000) continue;
            ServerPlayerEntity buyer = s.getPlayerManager().getPlayer(o.buyer);
            if (buyer == null) continue;
            double unit = Prices.unit(o.template.getItem());
            if (o.perItem < unit * 0.9) continue;                // gia qua thap -> khong ai ban
            int n = Math.max(1, (int) (o.remaining * (0.15 + RND.nextDouble() * 0.35)));
            n = Math.min(n, o.remaining);
            int left = n;
            while (left > 0) {
                int c = Math.min(o.template.getMaxCount(), left);
                buyer.getInventory().offerOrDrop(o.template.copyWithCount(c));
                left -= c;
            }
            o.remaining -= n;
            String who = FAKE_NAMES[RND.nextInt(FAKE_NAMES.length)];
            DonutLike.msg(buyer, "§a[Order] " + who + " đã giao " + n + "x " + o.template.getName().getString()
                + (o.remaining > 0 ? " (còn " + o.remaining + ")" : " — order hoàn tất"));
            if (o.remaining <= 0) it.remove();
        }
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv;

        Gui(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv;
            refresh();
        }

        void refresh() {
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < 45 && i < LIST.size(); i++) {
                FO o = LIST.get(i);
                ItemStack d = new ItemStack(o.item, Math.max(1, Math.min(o.remaining, o.item.getMaxCount())));
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eGiá mua: §a$" + Prices.money(o.per) + "§e /cái"),
                    Text.literal("§7Cần: §f" + o.remaining),
                    Text.literal("§7Người đặt: " + o.name),
                    Text.literal("§aClick: bán 1 stack §7| §aShift+click: bán tối đa"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, ShopHandler.icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            inv.setStack(49, ShopHandler.icon(Items.PAPER, "§fOrders", "§7Người mua tự đặt order, bán trực tiếp từ túi đồ", "§7Đổi mới mỗi 15 phút"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (slot >= 0 && slot < 45 && slot < LIST.size() && player instanceof ServerPlayerEntity sp
                    && (type == SlotActionType.PICKUP || type == SlotActionType.QUICK_MOVE) && button == 0) {
                sellTo(sp, LIST.get(slot), type == SlotActionType.QUICK_MOVE);
                refresh();
            }
            syncState();
        }

        void sellTo(ServerPlayerEntity sp, FO o, boolean all) {
            int limit = all ? o.remaining : Math.min(o.remaining, Math.max(1, o.item.getMaxCount()));
            int given = 0;
            PlayerInventory pi = sp.getInventory();
            for (int i = 0; i < 36 && given < limit; i++) {
                ItemStack s = pi.getStack(i);
                if (s.isEmpty() || !s.isOf(o.item) || s.get(DataComponentTypes.CUSTOM_DATA) != null) continue;
                int n = Math.min(s.getCount(), limit - given);
                s.decrement(n);
                given += n;
            }
            if (given == 0) { DonutLike.msg(sp, "§cBạn không có vật phẩm phù hợp trong túi."); return; }
            double pay = o.per * given;
            DonutLike.add(sp.getUuid(), pay);
            o.remaining -= given;
            ShopHandler.ting(sp);
            DonutLike.msg(sp, "§a[Sell] Đã bán " + given + "x " + new ItemStack(o.item).getName().getString()
                + " cho " + o.name + ": §e+$" + Prices.money(pay));
            if (o.remaining <= 0) {
                int idx = LIST.indexOf(o);
                FO n = make(RND);
                if (idx >= 0) LIST.set(idx, n);
            }
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
