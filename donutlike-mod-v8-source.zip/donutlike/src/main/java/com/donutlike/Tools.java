package com.donutlike;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.*;

/**
 * Cong cu Amethyst:
 *  - hammer  : cup 3x3 (nhin xuong: 3x3 sau 3 o)
 *  - treeaxe : chat 1 khuc go = do ca cay, la bien mat ngay
 *  - sellaxe : dao ruong/thung/shulker = ban het do ben trong, ruong KHONG bi pha
 *  - bucket  : xo nuoc vo han
 *  - potion  : chuot phai = x2.5 shard trong 30 phut
 */
public class Tools {
    static boolean busy = false;
    static final long POTION_MS = 30L * 60_000L;
    static final double POTION_MULT = 2.5;
    /** uuid -> thoi diem het hieu luc (ms) */
    static final Map<String, Long> BOOST = new HashMap<>();

    static String kind(ItemStack s) {
        if (s == null || s.isEmpty()) return "";
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        if (c == null) return "";
        return c.copyNbt().getString("dl_kind");
    }

    static double shardMult(UUID id) {
        Long end = BOOST.get(id.toString());
        return end != null && System.currentTimeMillis() < end ? POTION_MULT : 1.0;
    }

    static void init() {
        // ---- sellaxe: huy bo viec dao ruong, ban do ben trong ----
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity sp)) return true;
            if (!kind(sp.getMainHandStack()).equals("sellaxe")) return true;
            Block b = state.getBlock();
            boolean box = b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL || b instanceof ShulkerBoxBlock;
            if (!box || !(be instanceof Inventory inv)) return true;
            double total = 0; int n = 0;
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isEmpty() || s.get(DataComponentTypes.CUSTOM_DATA) != null) continue; // khong ban do dac biet
                double v = Prices.stack(s);
                if (v <= 0) continue;
                total += v; n += s.getCount();
                inv.setStack(i, ItemStack.EMPTY);
            }
            if (n == 0) { DonutLike.msg(sp, "§cRương trống hoặc không có gì bán được."); return false; }
            inv.markDirty();
            DonutLike.add(sp.getUuid(), total);
            ShopHandler.ting(sp);
            sp.sendMessage(Text.literal("§aĐã bán " + n + " vật phẩm trong rương: §e+$" + Prices.money(total)), true);
            return false;
        });

        // ---- hammer + treeaxe ----
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy || world.isClient || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return;
            String k = kind(sp.getMainHandStack());
            if (k.equals("hammer")) hammer(sp, sw, pos);
            else if (k.equals("treeaxe") && state.isIn(BlockTags.LOGS)) tree(sp, sw, pos);
        });

        // ---- potion ----
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
            ItemStack s = player.getStackInHand(hand);
            if (!kind(s).equals("potion")) return ActionResult.PASS;
            s.decrement(1);
            BOOST.put(sp.getUuid().toString(), System.currentTimeMillis() + POTION_MS);
            sp.getWorld().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 1f, 1f);
            DonutLike.msg(sp, "§d§lx2.5 SHARD §dtrong 30 phút!");
            return ActionResult.SUCCESS;
        });
    }

    /** goi moi 10 tick: nap lai xo nuoc vo han */
    static void tick(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isOf(Items.BUCKET) && kind(st).equals("bucket")) {
                    ItemStack n = new ItemStack(Items.WATER_BUCKET);
                    n.set(DataComponentTypes.CUSTOM_DATA, st.get(DataComponentTypes.CUSTOM_DATA));
                    n.set(DataComponentTypes.CUSTOM_NAME, st.get(DataComponentTypes.CUSTOM_NAME));
                    n.set(DataComponentTypes.LORE, st.get(DataComponentTypes.LORE));
                    p.getInventory().setStack(i, n);
                }
            }
        }
    }

    // ---------- 3x3 ----------
    static boolean breakable(ServerWorld w, BlockPos p) {
        BlockState st = w.getBlockState(p);
        if (st.isAir() || st.getHardness(w, p) < 0) return false;
        if (w.getBlockEntity(p) != null) return false; // khong pha ruong/may nung
        return st.getFluidState().isEmpty();
    }

    static void hammer(ServerPlayerEntity sp, ServerWorld w, BlockPos c) {
        busy = true;
        try {
            float pitch = sp.getPitch();
            List<BlockPos> list = new ArrayList<>();
            if (pitch > 55) {                       // nhin xuong: 3x3, sau 3 o
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int dy = 0; dy >= -2; dy--)
                    list.add(c.add(dx, dy, dz));
            } else if (pitch < -55) {               // nhin len: 3x3 phang
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) list.add(c.add(dx, 0, dz));
            } else {
                Direction f = sp.getHorizontalFacing();
                for (int a = -1; a <= 1; a++) for (int dy = -1; dy <= 1; dy++) {
                    if (f.getAxis() == Direction.Axis.X) list.add(c.add(0, dy, a));
                    else list.add(c.add(a, dy, 0));
                }
            }
            for (BlockPos p : list) {
                if (p.equals(c)) continue;
                if (sp.getMainHandStack().isEmpty()) break;
                if (!breakable(w, p)) continue;
                sp.interactionManager.tryBreakBlock(p);
            }
        } finally { busy = false; }
    }

    // ---------- chat ca cay ----------
    static void tree(ServerPlayerEntity sp, ServerWorld w, BlockPos start) {
        busy = true;
        try {
            Set<BlockPos> logs = new LinkedHashSet<>();
            Deque<BlockPos> q = new ArrayDeque<>();
            q.add(start);
            while (!q.isEmpty() && logs.size() < 400) {
                BlockPos c = q.poll();
                for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                    BlockPos n = c.add(dx, dy, dz);
                    if (logs.contains(n) || !w.getBlockState(n).isIn(BlockTags.LOGS)) continue;
                    if (Math.abs(n.getX() - start.getX()) > 8 || Math.abs(n.getZ() - start.getZ()) > 8) continue;
                    logs.add(n);
                    q.add(n);
                }
            }
            // chi do cay that (co la tu nhien ke ben), khong pha nha go
            boolean isTree = false;
            outer:
            for (BlockPos l : logs) {
                for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
                    BlockState s = w.getBlockState(l.add(dx, dy, dz));
                    if (s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT)) { isTree = true; break outer; }
                }
            }
            if (!isTree) return;
            for (BlockPos l : logs) {
                if (sp.getMainHandStack().isEmpty()) break;
                sp.interactionManager.tryBreakBlock(l);
            }
            // la bien mat ngay (roi do binh thuong)
            int removed = 0;
            for (BlockPos l : logs) {
                for (int dx = -3; dx <= 3 && removed < 800; dx++) for (int dy = -3; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++) {
                    BlockPos n = l.add(dx, dy, dz);
                    BlockState s = w.getBlockState(n);
                    if (s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT)) {
                        w.breakBlock(n, true, sp);
                        removed++;
                    }
                }
            }
        } finally { busy = false; }
    }
}
